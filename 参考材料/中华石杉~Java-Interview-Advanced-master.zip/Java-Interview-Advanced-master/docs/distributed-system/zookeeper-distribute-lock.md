
看图说话
![distributed-lock](/docs/distributed-system/images/zookeeper-distribute-lock.png)
一般很少自己手撸，curator，基于zk实现了一整套的高级功能

product_1_stock

curator.lock(“product_1_stock”)

/locks/product_1_stock
