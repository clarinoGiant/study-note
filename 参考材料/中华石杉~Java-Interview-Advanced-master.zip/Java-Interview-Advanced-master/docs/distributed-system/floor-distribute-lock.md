
《亿级流量电商详情页系统实战》，部署redis和zookeeper，redisson做分布式锁，curator做分布式锁，试一试
